# load the required packages
library(shiny)
library(shinydashboard)
library(ggplot2)
library(dplyr)
library(leaflet)
library(plotly)
library(reshape2)
library(remotes)


data <- read.csv('new.csv', stringsAsFactors = F, header = T)
df = data
df$Month <-
    factor(
        df$Month,
        levels = c(
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec"
        )
    )

res <- read.csv('result.csv', stringsAsFactors = F, header = T)
pow <- read.csv('newpower.csv',
                stringsAsFactors = F,
                header = T)


#Dashboard header carrying the title of the dashboard
header <- dashboardHeader(title = "Electricity Dashboard")

#Sidebar content of the dashboard
sidebar <- dashboardSidebar(sidebarMenu(
    menuItem(
        "Production",
        tabName = "Production",
        icon = icon("dashboard")
    ),
    
    selectInput(
        inputId = "city",
        label = "Country:",
        choices = list(
            "Australia" = 1,
            "China" = 2,
            "India" = 3,
            "Germany" = 4,
            "Canada" = 5,
            "USA" = 6,
            "Turkey" = 7
        ),
        selectize = FALSE
    ),
    selectInput(
        inputId = "year",
        label = "Year:",
        choices = list(
            "2018" = 2018,
            "2019" = 2019,
            "2020" = 2020
        ),
        selectize = FALSE
    ),
    menuItem(
        "Consumption",
        tabName = "Consumption",
        icon = icon("dashboard")
    ),
    selectInput(
        inputId = "year1",
        label = "Year:",
        choices = list(
            "2018" = 2018,
            "2019" = 2019,
            "2020" = 2020
        ),
        selectize = FALSE
    )
))

frow1 <- fluidRow(box(plotlyOutput("bar")),
                  #box(plotlyOutput("line")),
                  imageOutput("myImage"))

frow2 <- fluidRow(
    box(title = "Electricity Production by Fuel", plotlyOutput("pie", height = 350)),
    leafletOutput("map", width = 600)
)

# combine the two fluid rows to make the body
body <- dashboardBody(tags$head(tags$style(
    HTML(
        "
          .content-wrapper {
            background-color: linen !important;
          }
          .main-sidebar {
            background-color:#4a5057  !important;
          }
        "
    )
)),

tabItems(
    tabItem(tabName = "Production",
            fluidRow(
                box(
                    title = " Electricity Production Analysis of Various Countries ",
                    background = 'maroon',
                    width = 12
                ),
                column(width = 12,
                       box(plotlyOutput("bar")),
                       imageOutput("myImage")),
                box(title = "Electricity Production by Fuel", plotlyOutput("pie", height = 350)),
                box(title = "% Change in Net Production of Electricity in April 2019 and April 2020", leafletOutput("map", width = 700))
            )),
    tabItem(tabName = "Consumption",
            fluidRow(
                box(
                    title = "Electricity Consumption Analysis of a house located in Texas, USA ",
                    background = 'maroon',
                    width = 12
                ),
                box(title = "Does Temperature affect power consumption?", plotlyOutput("fig1")),
                box(title = " Is Power consumption year over year same?", plotlyOutput("fig2")),
                box(title = " When do we consume most power?", plotlyOutput("fig3"), width = 4),
                box(title = "Peak Hours for Power Consumption?", plotlyOutput("fig4"), width = 8)
                
            ))
))



#completing the ui part with dashboardPage
ui <-
    dashboardPage(title = 'Dashboard', header, sidebar, body, skin = 'purple')

# create the server functions for the dashboard
server <- function(input, output, session) {
    df_USA <- subset(df, df$country == "USA")
    df_China <- subset(df, df$country == "China")
    df_India <- subset(df, df$country == "India")
    df_Canada <- subset(df, df$country == "Canada")
    df_Australia <- subset(df, df$country == "Australia")
    df_Germany <- subset(df, df$country == "Germany")
    df_Turkey <- subset(df, df$country == "Turkey")
    
    
    output$bar <- renderPlotly({
        if (input$city == 1) {
            plotcity <- df_Australia
            tt <- "Australia"
        }
        else if (input$city == 2) {
            plotcity <- df_China
            tt <- "China"
            
        } else if (input$city == 5) {
            plotcity <- df_Canada
            tt <- "Canada"
            
        } else if (input$city == 3) {
            plotcity <- df_India
            tt <- "India"
            
        } else if (input$city == 4) {
            plotcity <- df_Germany
            tt <- "Germany"
            
        } else if (input$city == 6) {
            plotcity <- df_USA
            tt <- "USA"
        } else if (input$city == 7) {
            plotcity <- df_Turkey
            tt <- "Turkey"
        }
        
        if (input$year == 2018) {
            plotyear <- df %>% filter((country == tt) & (Year == 18))
        } else if (input$year == 2019) {
            plotyear <- df %>% filter((country == tt) & (Year == 19))
        } else if (input$year == 2020) {
            plotyear <- df %>% filter((country == tt) & (Year == 20))
        }
        
        cc <- paste(" Electricity Production of:", tt)
        yy <- paste(" In Year:", input$year)
        
        ggplot(data = plotyear,
               aes(
                   x = plotyear$Month,
                   y = plotyear$TOTAL.NET.PRODUCTION
               )) +
            geom_bar(position = "dodge", stat = "identity") + ylab("GigaWatt Hour") +
            xlab("Months") + ggtitle(paste0(cc, yy)) + labs(fill = "Region", color =
                                                                '#ba797e')
        
    })
    
    
    
    output$myImage <- renderImage({
        if (input$city == 1) {
            return(list(
                src = "Aus.png",
                height = "100%",
                width = "50%"
            ))
        } else if (input$city == 2) {
            return(list(
                src = "China.png",
                height = "100%",
                width = "50%"
            ))
        } else if (input$city == 5) {
            return(list(
                src = "Canada.png",
                height = "100%",
                width = "50%"
            ))
        } else if (input$city == 3) {
            return(list(
                src = "India.png",
                height = "100%",
                width = "50%"
            ))
        } else if (input$city == 4) {
            return(list(
                src = "Germany.png",
                height = "100%",
                width = "50%"
            ))
        } else if (input$city == 6) {
            return(list(
                src = "USA.png",
                height = "100%",
                width = "50%"
            ))
        } else if (input$city == 7) {
            return(list(
                src = "Turkey.png",
                height = "100%",
                width = "50%"
            ))
        }
    }, deleteFile = FALSE)
    
    
    output$pie <- renderPlotly({
        if (input$city == 1) {
            plotcity <- df_Australia
            tt <- "Australia"
        }
        else if (input$city == 2) {
            plotcity <- df_China
            tt <- "China"
            
        } else if (input$city == 5) {
            plotcity <- df_Canada
            tt <- "Canada"
            
        } else if (input$city == 3) {
            plotcity <- df_India
            tt <- "India"
            
        } else if (input$city == 4) {
            plotcity <- df_Germany
            tt <- "Germany"
            
        } else if (input$city == 6) {
            plotcity <- df_USA
            tt <- "USA"
        } else if (input$city == 7) {
            plotcity <- df_Turkey
            tt <- "Turkey"
        }
        
        if (input$year == 2018) {
            plotyear <- df %>% filter((country == tt) & (Year == 18))
        } else if (input$year == 2019) {
            plotyear <- df %>% filter((country == tt) & (Year == 19))
        } else if (input$year == 2020) {
            plotyear <- df %>% filter((country == tt) & (Year == 20))
        }
        
        coal = sum(plotyear$Coal)
        oil = sum(plotyear$Oil)
        Gas = sum(plotyear$Natural_Gas)
        Nuclear = sum(plotyear$Nuclear)
        Hydro = sum(plotyear$Hydro)
        Wind = sum(plotyear$Wind)
        Solar = sum(plotyear$Solar)
        
        labels = c('coal',
                   'oil',
                   'Gas',
                   'Nuclear',
                   'Hydro',
                   'Wind',
                   'Solar')
        values = c(coal, oil, Gas, Nuclear, Hydro, Wind, Solar)
        
        fig <-
            plot_ly(
                plotyear,
                labels = ~ labels,
                values = ~ values,
                type = 'pie',
                textposition = 'inside',
                textinfo = 'label+percent',
                insidetextfont = list(color = '#FFFFFF'),
                hoverinfo = 'text',
                #text = ~paste('$', Total, ' KWH'),
                marker = list(
                    colors = colors,
                    line = list(color = '#FFFFFF', width = 1)
                ),
                showlegend = TRUE
            )
    })
    
    
    
    output$map <- renderLeaflet({
        if (input$city == 1) {
            long <- 133.7751
            latt <- -25.2744
            content <- paste("Australia (-3.97%)")
        }
        else if (input$city == 2) {
            long <- 104.1954
            latt <- 35.86
            content <- paste("China (+0.74%)")
        } else if (input$city == 3) {
            latt <- 20.5937
            long <- 78.96
            content <- paste("India (-29.36%)")
        } else if (input$city == 4) {
            latt <- 51.1657
            long <- 10.4515
            content <- paste("Germany (-18.5%)")
        } else if (input$city == 5) {
            latt <- 62.227
            long <- -105.38
            content <- paste("Canada (-0.8%)")
        } else if (input$city == 6) {
            latt <- 37.0902
            long <- -95.7129
            content <- paste("USA (-6.32%)")
        } else if (input$city == 7) {
            latt <- 38.9637
            long <- 35.2433
            content <- paste("Turkey (-17.99%)")
        }
        
        rr <- tags$div(
            HTML(
                'Australia: -3.97%<br>
                  China: +0.74%<br>
                 India: -29.36%<br>
                 Germany: -18.5%<br>
                 Canada: -0.8%<br>
                 USA: -6.32%<br>
                 Turkey: -17.99%'
            )
            
        )
        
        
        
        
        
        leaflet(quakes) %>%
            addTiles() %>% setView(lng = 0,
                                   lat = -0,
                                   zoom = 1) %>% addControl(rr, position = "topright") %>%
            addMarkers(
                lng = long,
                lat = latt,
                label = content,
                labelOptions = labelOptions(
                    noHide = T,
                    textOnly = FALSE,
                    style =
                        list(
                            'color' = 'red',
                            'font-family' = 'serif',
                            'font-size' = '15px'
                        )
                )
            )
        
    })
    
    
    output$fig1 <- renderPlotly({
        if (input$year1 == 2018) {
            plotyear <- res %>% filter(Year == "2018")
        } else if (input$year1 == 2019) {
            plotyear <- res %>% filter(Year == "2019")
        } else if (input$year1 == 2020) {
            plotyear <- res %>% filter(Year == "2020")
        }
        
        totaltemp <-
            plotyear %>% group_by(Month) %>% summarise(Total = mean(Temp_avg))
        totaltemp1 <-
            plotyear %>% group_by(Month) %>% summarise(Total = sum(Power.KWH.))
        
        fig <- plot_ly(totaltemp1)
        fig <-
            fig %>% add_trace(
                x = ~ Month,
                y = ~ Total,
                type = 'bar',
                name = 'Electricity',
                marker = list(color = '#c7abc7'),
                hoverinfo = "text",
                text = ~ paste(Total, ' KWH')
            )
        fig <-
            fig %>% add_trace(
                x = ~ Month,
                y = ~ totaltemp$Total,
                type = 'scatter',
                mode = 'dottedlines',
                name = 'Temperature',
                yaxis = 'y2',
                line = list(color = '#45171D'),
                hoverinfo = "text",
                text = ~ paste(Total, 'F')
            )
        fig <-
            fig %>% layout(
                title = 'Monthly Electricity consumption and Temperature Measurements',
                xaxis = list(title = "Months", type = 'category'),
                yaxis = list(
                    side = 'left',
                    title = 'Electricity in KWH',
                    showgrid = TRUE,
                    zeroline = FALSE
                ),
                yaxis2 = list(
                    side = 'right',
                    overlaying = "y",
                    title = 'Temperature in degrees F',
                    showgrid = FALSE,
                    zeroline = FALSE
                )
            )
        
        
    })
    
    
    output$fig2 = renderPlotly({
        totalpower <-
            res %>% group_by(Year) %>% summarise(Total = sum(Power.KWH.))
        
        p <- ggplot(data = totalpower, aes(x = Year, y = Total)) +
            geom_bar(position = "dodge", stat = "identity") + ylab("Kilowatt Hour") +
            xlab("Year")  + labs(fill = "Region")
        p + ggtitle("Yearly Consumption")
        
    })
    
    
    output$fig4 = renderPlotly({
        if (input$year1 == 2018) {
            plotyear <- pow %>% filter(Year == "2018")
        } else if (input$year1 == 2019) {
            plotyear <- pow %>% filter(Year == "2019")
        } else if (input$year1 == 2020) {
            plotyear <- pow %>% filter(Year == "2020")
        }
        
        
        
        days <-
            plotyear %>% group_by(notes, Time) %>% summarise(Total = mean(Value..kWh.))
        
        vacation <- days %>% filter(notes == "vacation")
        weekday <- days %>% filter(notes == "weekday")
        weekend <- days %>% filter(notes == "weekend")
        if (input$year1 == 2020) {
            lockdown <- days %>% filter(notes == "COVID_lockdown")
        }
        
        
        
        
        
        fig <- plot_ly(vacation)
        fig <-
            fig %>% add_trace(
                x = ~ Time,
                y = ~ Total,
                type = 'scatter',
                mode = 'dottedlines',
                name = 'Vacation',
                line = list(color = '#91d2e3'),
                hoverinfo = "text",
                text = ~ paste(Total, ' KWH')
            )
        fig <-
            fig %>% add_trace(
                x = ~ Time,
                y = ~ weekday$Total,
                type = 'scatter',
                mode = 'dottedlines',
                name = 'weekday',
                line = list(color = 'blue'),
                hoverinfo = "text",
                text = ~ paste(Total, 'F')
            )
        fig <-
            fig %>% add_trace(
                x = ~ Time,
                y = ~ weekend$Total,
                type = 'scatter',
                mode = 'dottedlines',
                name = 'weekend',
                line = list(color = 'orange'),
                hoverinfo = "text",
                text = ~ paste(Total, 'F')
            )
        if (input$year1 == 2020) {
            fig <-
                fig %>% add_trace(
                    x = ~ Time,
                    y = ~ lockdown$Total,
                    type = 'scatter',
                    mode = 'dottedlines',
                    name = 'Lockdown',
                    line = list(
                        color = 'red',
                        length = 8,
                        width = 2.5,
                        dash = 'dot'
                    ),
                    hoverinfo = "text",
                    text = ~ paste(Total, 'F')
                )
            
        }
        
        fig <- fig %>% layout(
            title = 'Average Power usage per day',
            xaxis = list(
                title = 'Hour of the Day',
                showgrid = TRUE,
                zeroline = TRUE,
                type = 'category'
            ),
            yaxis = list(
                side = 'left',
                title = 'Electricity in KWH',
                showgrid = TRUE,
                zeroline = TRUE
            )
        )
        
        
        
    })
    
    
    output$fig3 <- renderPlotly({
        if (input$year1 == 2018) {
            plotyear <- pow %>% filter(Year == "2018")
        } else if (input$year1 == 2019) {
            plotyear <- pow %>% filter(Year == "2019")
        } else if (input$year1 == 2020) {
            plotyear <- pow %>% filter(Year == "2020")
        }
        
        
        
        pow_weekday <-
            plotyear %>% group_by(notes) %>% summarise(Total = mean(Value..kWh.))
        
        fig <-
            plot_ly(
                pow_weekday,
                labels = ~ pow_weekday$notes,
                values = ~ pow_weekday$Total,
                type = 'pie',
                textposition = 'inside',
                textinfo = 'label+percent',
                insidetextfont = list(color = '#FFFFFF'),
                hoverinfo = 'text',
                text = ~ paste('$', Total, ' KWH'),
                marker = list(
                    colors = colors,
                    line = list(color = '#FFFFFF', width = 1)
                ),
                showlegend = TRUE
            )
        fig <-
            fig %>% layout(
                title = 'Power Usage per hour in Percentage',
                xaxis = list(
                    showgrid = FALSE,
                    zeroline = FALSE,
                    showticklabels = FALSE
                ),
                yaxis = list(
                    showgrid = FALSE,
                    zeroline = FALSE,
                    showticklabels = FALSE
                )
            )
        
        
    })
    
    
}

shinyApp(ui = ui, serve = server)
